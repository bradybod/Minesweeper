package cs2410.assn8.controllers;

/**
 * Add a description of the class here
 *
 * @author Brady Bodily
 * @version xxx
 */
public enum Size {
    SMALL, MEDIUM, LARGE
}
