package cs2410.assn8.model;

/**
 * Add a description of the class here
 *
 * @author Brady Bodily
 * @version xxx
 */
public class DataEntry {
    public String name1;
    public Integer score1;

    public DataEntry(String name, Integer score) {
        name1 = name;
        score1 = score;
    }

}
